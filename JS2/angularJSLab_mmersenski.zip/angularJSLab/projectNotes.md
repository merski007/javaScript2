#notes#

- PDF file download window
# COMPLETE - Dropdown list for user to select which week of files they want to view in page list
# COMPLETE - populate this dropdown with a json file on server
# COMPLETE - Populate a page list with a json file on server
# COMPLETE - each file will be named with the week and contain all data for the files from that week
# COMPLETE - fileName, description, etc.. (start small for the mockup)
# COMPLETE - Search bar for user to filter the view in page list
# COMPLETE - each file will have a checkbox for the user to click on
# COMPLETE - Download (submit) button for user to click on to download all checked files
# COMPLETE - add a select all/clear button

- USPS tracking window
    - Display a grid with the tracking info for the user
        - tracking info will be a json file on server
        - grab username from DOM

- TakeDown_Put Up List window
    - Weekly PDF file that users will click to download
