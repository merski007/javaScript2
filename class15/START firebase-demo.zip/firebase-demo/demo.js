// JavaScript Document
// database reference
$(document).ready(function(e){
	
	// form submit event
	$('#addTodoForm').submit(addTodo);
});



// process the form (add to database)
function addTodo(e){
	e.preventDefault();
	
	// create object to store
	var todo = {
		todo: $('#newTodo').val(),
		duedate: $('#newDueDate').val()
	};
	
	// add to database
	//...
	
	
	// clear form
	$('#addTodoForm input[type=text]').val('');
}