// Initialize Phaser, and create a 400x500px game
var game = new Phaser.Game(400, 500, Phaser.AUTO, 'gameDiv', {preload: preload, create: create, update: update, render: render});


// This function will be executed once at the beginning of the game 
function preload(){ 
	// set stage
	game.stage.backgroundColor = '#71c5cf';    
	
	
}

// This function is called after the preload function
function create() { 
	// Set the physics system
	game.physics.startSystem(Phaser.Physics.ARCADE);


}

// This function is called 60 times per second    
// It contains the game's logic
function update() {
		
		   
}

// this is called after the "update" function
// in this case, it's used for strictly for debugging
function render(){  
	

}

